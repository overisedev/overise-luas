-- Generated with Luie @ https://lua.tools/
-- 4992070 - Sort Them Ducks
-- Generated 2026-08-13 19:01:11 UTC
-- # Depots (Total/DLC/Shared): 1/0/0

-- Main AppID
addappid(4992070)

-- Main Depots
addappid(4992071, 1, "4607a37d6d00aa9fc2a284c981b1983b05dac8c5519402ebd5aa206f97e0a392")
-- setManifestid(4992071, "460713304560995569", 1532500864)
