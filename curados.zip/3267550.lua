-- Generated with Luie @ https://lua.tools/
-- 3267550 - The Backrooms: Rescue Expedition
-- Generated 2026-08-12 18:27:55 UTC
-- # Depots (Total/DLC/Shared): 3/0/2

-- Main AppID
addappid(3267550)

-- Main Depots
addappid(3267551, 1, "90d0fb98f797dcc980361f80a0a9ec9743efa1396eb9dfc875074475f2727ab6") -- (windows, 64-bit)
-- setManifestid(3267551, "7381171839099293074", 8769202046)

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
