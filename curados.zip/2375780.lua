-- Generated with Luie @ https://lua.tools/
-- 2375780 - Beam Eye Tracker
-- Generated 2026-08-21 21:23:09 UTC
-- # Depots (Total/DLC/Shared): 1/0/0

-- Main AppID
addappid(2375780, 1, "b01541c2eb2afb726836e95532ccfd5e6355de043112e8f80cab9209401a8c55")
addtoken(2375780, "11633826903461235409")

-- Main Depots
addappid(2375781, 1, "36327ca060d94c61bde1b0518cc17b2c9e035f7829155f0b90a846d24a27766c") -- (windows, 64-bit)
-- setManifestid(2375781, "8178344635031504960", 524818394)
