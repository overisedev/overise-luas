-- 2406770's Lua and Manifest Created by Hubcap Manifest
-- Bodycam
-- Created: September 08, 2026 at 13:19:40 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2406770, 1, "70969ed45a39a813850ed9d81a50af9aabc5fc4ebd8fc1216ed260e04487cb50") -- Bodycam
-- MAIN APP DEPOTS
addappid(2406771, 1, "0456324ba6c023dafc26bedc6005e6145a7b03bfe59a6d2806bf7e07ef54e6c2") -- Depot 2406771
setManifestid(2406771, "1912806340035433358", 59943254682)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)