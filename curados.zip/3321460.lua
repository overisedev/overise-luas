-- 3321460's Lua and Manifest Created by Hubcap Manifest
-- Crimson Desert Enhanced
-- Created: September 04, 2026 at 00:52:26 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 8
-- Total DLCs: 3 (1 excluded)
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(3321460, 1, "dc014470e47064263f3003feb526a87cc64784292e2a608455d18fa70ec2c1e0") -- Crimson Desert Enhanced
-- MAIN APP DEPOTS
addappid(3321461, 1, "e2e570c84eb8b4cfe9c20268cd30b84f8c1c7c076691c92ae8c5ba7b510b8a95") -- Depot 3321461
setManifestid(3321461, "3540302611239512787", 152601596513)
addappid(3321462, 1, "6eb3bfe7d16b9eb6441dba4f7d18b341fe83ab2f1e9385d042ce622f38a600cb") -- Depot 3321462
setManifestid(3321462, "304563384328720229", 159292578528)
addappid(3321463, 1, "5c5b7a3590b231b68c3c0e9c33b4ced510f2281cc35ab7f552ab782931ce22b3") -- Depot 3321463
setManifestid(3321463, "4530244824200375724", 1809929222)
addappid(3321464, 1, "2333a1f0f77d75fa09864aeb71fa6fbafc6ee59bde5f1f13922cba1a0c8aa777") -- Depot 3321464
setManifestid(3321464, "7928376223497033917", 1941666211)
addappid(3321465, 1, "58dfe68b6d03e20bef08407af32e2c1c53ec82e8197e4acff6018a16d5da2b51") -- Depot 3321465
setManifestid(3321465, "8819069319322293697", 1668864630)
addappid(3321466, 1, "0456065fe718c350f1f71a6bb81e5601ab8a747e8b0c002efa6fd8db27caa4ed") -- Depot 3321466
setManifestid(3321466, "9134211451788367989", 1963396515)
addappid(3321467, 1, "b8a8a3d8540f34ce307c425fc47acd66a35b7d19d24004ceee088aa8fdd0d407") -- Depot 3321467
setManifestid(3321467, "6504286068078412358", 1794274305)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4024620) -- Crimson Desert - Deluxe Pack
addappid(4024630) -- Crimson Desert - Pre Order Pack
addtoken(4024630, "17135069641874014023")
addappid(4193060) -- Crimson Desert - Ultimate Pack
-- EXCLUDED DLCS:
-- UNRELEASED DLCS (COMMENTED OUT)
-- addappid(5001840) -- Crimson Desert Enhanced: Charting the Unknown (unreleased)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(3321469) -- Depot 3321469 (empty depot)
-- addappid(4783050) -- Depot 4783050 (empty depot)