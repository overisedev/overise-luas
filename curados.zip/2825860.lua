-- Generated with Luie @ https://lua.tools/
-- 2825860 - The Sinking City 2
-- Generated 2026-08-28 15:46:47 UTC
-- # Depots (Total/DLC/Shared): 6/3/2

-- Main AppID
addappid(2825860)

-- Main Depots
addappid(2825861, 1, "f02c681f5c694511752aaec61e14bd203f901b3f2d7b30ac2bda2318d9d2b699")
-- setManifestid(2825861, "8701471887458519044", 52236346262)

-- DLC's (no depot keys required)
addappid(4265340) -- The Sinking City 2 – The Arkham Field Kit
addappid(4265420) -- The Sinking City 2 – The Holloway Manor
addappid(4265440) -- The Sinking City 2 – Chthonic Arsenal

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)

-- Missing Depots (We don't have the keys yet lol): 4265450, 4265461, 4265462
