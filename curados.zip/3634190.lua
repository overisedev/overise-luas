-- Generated with Luie @ https://lua.tools/
-- 3634190 - MXGP 26 - The official game
-- Generated 2026-10-01 22:43:47 UTC
-- # Depots (Total/DLC/Shared): 3/0/2

-- Main AppID
addappid(3634190)

-- Main Depots
addappid(3634191, 1, "6f0254fc575a1d52583c9c15471df040ae9a5f72a7e22b55a03ef3cb648e4dba")
setManifestid(3634191, "4086207878589555971", 22537190049)

-- DLC's (no depot keys required)
addappid(4847440) -- MXGP 26 - Scrubdesignz Liveries
addappid(4847450) -- MXGP 26 - Fox Holeshot Pack

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
