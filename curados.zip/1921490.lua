-- Generated with Luie @ https://lua.tools/
-- 1921490 - Wild Blue Skies
-- Generated 2026-08-15 20:35:13 UTC
-- # Depots (Total/DLC/Shared): 1/0/0

-- Main AppID
addappid(1921490)

-- Main Depots
addappid(1921491, 1, "fa9731c470e6384d128d5847b038b59fb76b9ea5288ae9584b9861a1ebfd88c4") -- (windows)
-- setManifestid(1921491, "1526186745412442091", 1795803449)
