-- Generated with Luie @ https://lua.tools/
-- 3017860 - DOOM: The Dark Ages
-- Generated 2026-07-09 23:54:39 UTC
-- # Depots (Total/DLC/Shared): 9/0/2

-- Main AppID
addappid(3017860, 1, "ce570e5aa3168b1e9c8d2004a3b93db4c11a44cf8b9a99158ae4c1baf9384dbb")

-- Main Depots
addappid(3017862, 1, "b537907a613fd29911d2e311eb41fd2f0b309324601b0ef164c8520562eac290") -- (windows, 64-bit)
-- setManifestid(3017862, "8197197764663749946", 382466459)
addappid(3017863, 1, "0c010bdf1623542793fb5765875c715494c4a6c78856f75c124aa7d31f3021cd") -- (windows, 64-bit)
-- setManifestid(3017863, "5147735178128053244", 403)
addappid(3017864, 1, "35f0d11b6d2b729dd8e5f50a21e7b0300e8d6b79fc6ba487f4198ca6d3402c0d") -- (windows, 64-bit)
-- setManifestid(3017864, "4051834565771554326", 12269058907)
addappid(3017865, 1, "558521d6ef4cac7a1318bb55268dc878b72482482691e7791ea81bff06c73694") -- (windows, 64-bit)
-- setManifestid(3017865, "6508691013012284956", 0)
addappid(3017866, 1, "cc9112a06785fd0d7f6e24a50702f1f71e655e35caf8fb3ea09f6036680c0fe4") -- (windows, 64-bit)
-- setManifestid(3017866, "51450828051076476", 232)
addappid(3017867, 1, "8ffa78f10846725bed8d48d1a182cf4088f770691c44561b2d167f84fdc60789") -- (windows, 64-bit)
-- setManifestid(3017867, "7418049215055797629", 93399709328)
addappid(3017868, 1, "fb3bda82e733857d05419dce15179a1aa642b840af21ef69520346fe8a00e20e")
-- setManifestid(3017868, "7542505685871058323", 79791458)

-- DLC's (no depot keys required)
addappid(3363930) -- DOOM: The Dark Ages - Preorder Content
addappid(3363940) -- DOOM: The Dark Ages - Premium Content
addappid(3469450) -- DOOM: The Dark Ages | Revelations
addappid(3698350) -- DOOM: The Dark Ages - Premium Upgrade

-- Shared Depots (Runtimes / Launchers / ETC)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- (windows)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- (windows)
