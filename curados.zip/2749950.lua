-- Generated with Luie @ https://lua.tools/
-- 2749950 - Esports Manager 2026
-- Generated 2026-07-09 16:23:35 UTC
-- # Depots (Total/DLC/Shared): 1/0/0

-- Main AppID
addappid(2749950)

-- Main Depots
addappid(2749951, 1, "bbca891b03feb6b30b61373f1fdb51376656cf5ab5fee47855c742e6878b0598")
-- setManifestid(2749951, "8340420045123620967", 4430582807)
