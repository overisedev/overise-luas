-- Generated with Luie @ https://lua.tools/
-- 4500150 - Table 9
-- Generated 2026-07-16 20:01:16 UTC
-- # Depots (Total/DLC/Shared): 2/0/0

-- Main AppID
addappid(4500150)

-- Main Depots
addappid(4500151, 1, "2fe836a9ab5b5c45bc8a164eab9b7472354c337f8bdde67acc21b8a231512787") -- (windows, 64-bit)
-- setManifestid(4500151, "7565498883607116787", 616345887)

-- Missing Depots (We don't have the keys yet lol): 4500152
