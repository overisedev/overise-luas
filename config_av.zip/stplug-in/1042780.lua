addappid(1042780)
addappid(1042781,0,"5bd8dccaed5e3a40bb1ed9e768d23c689703177970e520cd9230fe9706d8a514")
-- setManifestid(1042781,"7422837640473682341")
addappid(1042782,0,"e09190a354b53eccade84ffbfe143ebca443b9a444dcba59b68a4f97014f95eb")
-- setManifestid(1042782,"1787784344867106554")
addappid(1042783,0,"496eac5d731ba388462cf1b021f2701761409f4d761e6b7220ee1620429ffef8")
-- setManifestid(1042783,"8340499281538014649")
-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords
