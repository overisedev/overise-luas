-- Generated with Luie @ https://lua.tools/
-- 3639070 - BLACKWOOD
-- Generated 2026-09-16 18:39:17 UTC
-- # Depots (Total/DLC/Shared): 1/0/0

-- Main AppID
addappid(3639070)

-- Main Depots
addappid(3639071, 1, "a8bc6cbde85155fc1ca0e66d9af8e245cc341495b27ec7175fa1ac3f7f21df92")
setManifestid(3639071, "4842142721058281602", 26342877768)

-- DLC's (no depot keys required)
addappid(5237010) -- Supporter Edition
